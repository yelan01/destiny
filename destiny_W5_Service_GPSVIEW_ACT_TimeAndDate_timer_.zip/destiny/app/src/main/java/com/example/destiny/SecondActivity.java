package com.example.destiny;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

// *** 核心修改：引入 osmdroid 相關的類別 ***
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Polyline;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

// *** 核心修改：不再需要實現 OnMapReadyCallback ***
public class SecondActivity extends AppCompatActivity {

    private static final String TAG = "SecondActivity";

    // UI 元件
    private TextView tvHeaderInfo, tvMainDistance, tvMainTimer;
    private Button btnStartStop, btnNextStep;

    // *** 核心修改：MapView 使用 osmdroid 的版本 ***
    private MapView mapView;
    private MyLocationNewOverlay myLocationOverlay; // 用於顯示「我的位置」
    private Polyline pathPolyline; // 用於繪製軌跡
    private final List<GeoPoint> pathPoints = new ArrayList<>(); // 軌跡點

    // 狀態變數、解鎖條件等都維持不變
    private boolean isTracking = false;
    private float totalDistance = 0f;
    private long elapsedTimeMillis = 0;
    private String currentLocationName = "獲取中...";
    private int consecutiveClickCount = 0;
    private long lastClickTime = 0;
    private static final int CLICK_THRESHOLD_MS = 1500;
    private static final int CLICK_COUNT_TO_UNLOCK = 5;
    private static final float TARGET_DISTANCE_METERS = 100f;
    private static final int TARGET_TIME_SECONDS = 10;

    private FusedLocationProviderClient fusedLocationClient;
    private ActivityResultLauncher<String[]> permissionRequest;
    private final Handler clockHandler = new Handler(Looper.getMainLooper());
    private Runnable clockRunnable;

    private final BroadcastReceiver runningUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction() != null && intent.getAction().equals(RunningService.ACTION_BROADCAST)) {
                totalDistance = intent.getFloatExtra(RunningService.EXTRA_DISTANCE, 0);
                elapsedTimeMillis = intent.getLongExtra(RunningService.EXTRA_ELAPSED_TIME, 0);
                currentLocationName = intent.getStringExtra(RunningService.EXTRA_LOCATION_NAME);

                if (intent.hasExtra(RunningService.EXTRA_LOCATION)) {
                    Location location = intent.getParcelableExtra(RunningService.EXTRA_LOCATION);
                    if (location != null) {
                        updateMap(location);
                    }
                }

                updateRunningUI();
                checkUnlockConditions();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // *** 核心修改：在使用任何 osmdroid 功能前，必須先設定 Configuration ***
        Context ctx = getApplicationContext();
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx));
        Configuration.getInstance().setUserAgentValue(getPackageName());

        setContentView(R.layout.activity_second);

        initViews();
        setupMap(); // 初始化地圖設定

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        initPermissionLauncher();
        setupListeners();
        fetchInitialLocation();
    }

    private void initViews() {
        tvHeaderInfo = findViewById(R.id.tv_header_info);
        tvMainDistance = findViewById(R.id.tv_main_distance);
        tvMainTimer = findViewById(R.id.tv_main_timer);
        btnStartStop = findViewById(R.id.btn_start_stop);
        btnNextStep = findViewById(R.id.btn_next_step);
        mapView = findViewById(R.id.mapView); // 找到 osmdroid 的 MapView
    }

    /**
     * *** 新增：設定 osmdroid 地圖的方法 ***
     */
    private void setupMap() {
        mapView.setTileSource(TileSourceFactory.MAPNIK); // 設定地圖圖層來源
        mapView.setMultiTouchControls(true); // 允許多點觸控縮放
        mapView.getController().setZoom(15.0); // 設定預設縮放級別

        // 初始化軌跡線
        pathPolyline = new Polyline();
        pathPolyline.setColor(Color.BLUE);
        pathPolyline.setWidth(10f);
        mapView.getOverlays().add(pathPolyline);

        // 初始化「我的位置」圖層
        myLocationOverlay = new MyLocationNewOverlay(new GpsMyLocationProvider(this), mapView);
        myLocationOverlay.enableMyLocation(); // 啟用定位
        myLocationOverlay.setDrawAccuracyEnabled(true); // 顯示精度圈
        mapView.getOverlays().add(myLocationOverlay);
    }

    /**
     * *** 修改：使用 osmdroid 的 API 來更新地圖 ***
     */
    private void updateMap(Location location) {
        if (mapView == null) return;

        GeoPoint currentGeoPoint = new GeoPoint(location.getLatitude(), location.getLongitude());

        // 將新座標點加入軌跡列表
        pathPoints.add(currentGeoPoint);
        pathPolyline.setPoints(pathPoints);

        // 手動讓鏡頭跟隨
        if (isTracking) {
            mapView.getController().animateTo(currentGeoPoint);
        }

        mapView.invalidate(); // 重繪地圖
    }

    @SuppressLint("MissingPermission")
    private void fetchInitialLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.getLastLocation()
                    .addOnSuccessListener(this, location -> {
                        if (location != null) {
                            updateLocationNameFromCoords(location);
                            // *** 修改：讓地圖一開始就定位到使用者位置 ***
                            if (mapView != null) {
                                GeoPoint initialGeoPoint = new GeoPoint(location.getLatitude(), location.getLongitude());
                                mapView.getController().setCenter(initialGeoPoint);
                                mapView.getController().setZoom(17.0);
                            }
                        } else {
                            currentLocationName = "無法獲取位置";
                            updateHeaderInfo();
                        }
                    });
        } else {
            currentLocationName = "沒有定位權限";
            updateHeaderInfo();
        }
    }

    private void toggleTracking() {
        isTracking = !isTracking;
        if (isTracking) {
            // *** 修改：開始跑步時，清空舊的軌跡 ***
            pathPoints.clear();
            if (pathPolyline != null) {
                pathPolyline.setPoints(pathPoints);
            }
            mapView.invalidate(); // 清除後重繪

            // 啟動服務的程式碼
            Intent serviceIntent = new Intent(this, RunningService.class);
            serviceIntent.putExtra("INITIAL_LOCATION_NAME", currentLocationName);
            btnStartStop.setText("停止");
            resetUIForNewRun();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
        } else {
            // 停止服務的程式碼
            btnStartStop.setText("開始");
            stopService(new Intent(this, RunningService.class));
        }
    }

    // --- osmdroid 需要在 Activity 的生命週期中被管理 ---
    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume(); // MapView 需要這個
        LocalBroadcastManager.getInstance(this).registerReceiver(runningUpdateReceiver, new IntentFilter(RunningService.ACTION_BROADCAST));
        startClock();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mapView.onPause(); // MapView 需要這個
        LocalBroadcastManager.getInstance(this).unregisterReceiver(runningUpdateReceiver);
        stopClock();
    }

    // ----- 以下為其他未變動的方法 -----
    // 您可以將這些方法折疊起來，它們的功能與之前相同

    private void initPermissionLauncher(){
        permissionRequest = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                permissions -> {
                    Boolean fineLocationGranted = permissions.getOrDefault(Manifest.permission.ACCESS_FINE_LOCATION, false);
                    Boolean postNotificationsGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU || permissions.getOrDefault(Manifest.permission.POST_NOTIFICATIONS, false);

                    if (fineLocationGranted && (postNotificationsGranted != null && postNotificationsGranted)) {
                        fetchInitialLocation(); // 獲取權限後，重新定位一次
                    } else {
                        Toast.makeText(this, "需要定位和通知權限才能使用地圖和跑步功能", Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void setupListeners() {
        btnStartStop.setOnClickListener(v -> handleStartStopClick());
        btnNextStep.setOnClickListener(v -> {
            Intent intent = new Intent(SecondActivity.this, ThirdActivity.class);
            intent.putExtra("RUN_DISTANCE", totalDistance);
            intent.putExtra("RUN_TIME", elapsedTimeMillis);
            startActivity(intent);
        });
    }

    private void updateHeaderInfo() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        String currentTime = sdf.format(new Date());
        String headerText = currentTime + " " + currentLocationName;
        tvHeaderInfo.setText(headerText);
    }

    private void updateRunningUI() {
        tvMainDistance.setText(String.format(Locale.getDefault(), "%.0f", totalDistance));
        tvMainTimer.setText(formatDuration(elapsedTimeMillis));
    }

    private void startClock() {
        clockRunnable = new Runnable() {
            @Override
            public void run() {
                updateHeaderInfo();
                clockHandler.postDelayed(this, 1000);
            }
        };
        clockHandler.post(clockRunnable);
    }

    private void stopClock() {
        if (clockRunnable != null) {
            clockHandler.removeCallbacks(clockRunnable);
        }
    }

    private void updateLocationNameFromCoords(Location location) {
        new Thread(() -> {
            Geocoder geocoder = new Geocoder(this, Locale.TAIWAN);
            try {
                List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                if (addresses != null && !addresses.isEmpty()) {
                    Address address = addresses.get(0);
                    String city = address.getAdminArea();
                    String district = address.getLocality();
                    StringBuilder nameBuilder = new StringBuilder();
                    if (city != null) nameBuilder.append(city);
                    if (district != null) nameBuilder.append(" ").append(district);
                    currentLocationName = nameBuilder.length() > 0 ? nameBuilder.toString() : "未知區域";
                } else {
                    currentLocationName = "無法解析地名";
                }
            } catch (IOException e) {
                Log.e(TAG, "Geocoder failed", e);
                currentLocationName = "位置服務錯誤";
            }
            runOnUiThread(this::updateHeaderInfo);
        }).start();
    }

    private void handleStartStopClick() {
        if (isTracking) {
            toggleTracking();
            handleConsecutiveClicks();
        } else {
            checkPermissionsAndStart();
        }
    }

    private void checkPermissionsAndStart() {
        String[] requiredPermissions = {Manifest.permission.ACCESS_FINE_LOCATION};
        // 對於 osmdroid，通知權限不是前景服務的絕對必要條件，可以簡化
        boolean allPermissionsGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;

        if (allPermissionsGranted) {
            toggleTracking();
        } else {
            permissionRequest.launch(requiredPermissions);
        }
    }

    private void resetUIForNewRun() {
        totalDistance = 0f;
        elapsedTimeMillis = 0;
        updateRunningUI();
        btnNextStep.setEnabled(false);
    }

    private String formatDuration(long millis) {
        long hours = TimeUnit.MILLISECONDS.toHours(millis);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(hours);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(minutes);
        long hundredths = (millis / 10) % 100;
        return String.format(Locale.getDefault(), "%02d:%02d:%02d.%02d", hours, minutes, seconds, hundredths);
    }

    private void checkUnlockConditions() {
        if (!btnNextStep.isEnabled()) {
            if (totalDistance >= TARGET_DISTANCE_METERS) {
                unlockNextButton("跑步距離達標");
            } else if (TimeUnit.MILLISECONDS.toSeconds(elapsedTimeMillis) >= TARGET_TIME_SECONDS) {
                unlockNextButton("跑步時間達標");
            }
        }
    }

    private void handleConsecutiveClicks() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastClickTime < CLICK_THRESHOLD_MS) {
            consecutiveClickCount++;
        } else {
            consecutiveClickCount = 1;
        }
        lastClickTime = currentTime;
        if (consecutiveClickCount >= CLICK_COUNT_TO_UNLOCK) {
            unlockNextButton("連續點擊解鎖");
        }
    }

    private void unlockNextButton(String reason) {
        if (!btnNextStep.isEnabled()) {
            btnNextStep.setEnabled(true);
            Toast.makeText(this, "已解鎖下一步 (" + reason + ")", Toast.LENGTH_SHORT).show();
        }
    }
}
